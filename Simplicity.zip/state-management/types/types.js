export const GET_ERRORS = "GET_ERRORS";
